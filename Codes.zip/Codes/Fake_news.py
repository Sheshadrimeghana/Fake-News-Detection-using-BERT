#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import torch
print("GPU available:", torch.cuda.is_available())
print("Device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")


# In[ ]:


get_ipython().system('pip install -q pandas numpy scikit-learn nltk transformers torch tqdm')


# In[ ]:


import pandas as pd
import numpy as np
import re
import nltk
import pickle

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, TensorDataset
import torch
from tqdm import tqdm


# In[ ]:


nltk.download('stopwords')
from nltk.corpus import stopwords


# In[ ]:


from google.colab import files
files.upload()


# In[ ]:


fake_df = pd.read_csv("Fake.csv")
true_df = pd.read_csv("True.csv")

fake_df["label"] = 0   # Fake
true_df["label"] = 1   # Real

df = pd.concat([fake_df, true_df], axis=0)
df = df.sample(frac=1).reset_index(drop=True)

df = df[["text", "label"]]
df.head()


# In[ ]:


stop_words = set(stopwords.words("english"))

def clean_text(text):
    text = text.lower()
    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    text = ' '.join(word for word in text.split() if word not in stop_words)
    return text

df["text"] = df["text"].apply(clean_text)


# In[ ]:


X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["label"], test_size=0.2, random_state=42
)


# In[ ]:


tfidf = TfidfVectorizer(max_features=5000)

X_train_tfidf = tfidf.fit_transform(X_train)
X_test_tfidf = tfidf.transform(X_test)


# In[ ]:


clf = LogisticRegression(max_iter=1000)
clf.fit(X_train_tfidf, y_train)


# In[ ]:


y_pred = clf.predict(X_test_tfidf)

print("Accuracy :", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall   :", recall_score(y_test, y_pred))
print("F1 Score :", f1_score(y_test, y_pred))

print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))


# In[ ]:


with open("tfidf_vectorizer.pkl", "wb") as f:
    pickle.dump(tfidf, f)

with open("fake_news_classifier.pkl", "wb") as f:
    pickle.dump(clf, f)


# In[ ]:


tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
bert_model = BertForSequenceClassification.from_pretrained(
    "bert-base-uncased", num_labels=2
)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
bert_model.to(device)


# In[ ]:


train_encodings = tokenizer(
    list(X_train), truncation=True, padding=True, max_length=128
)
test_encodings = tokenizer(
    list(X_test), truncation=True, padding=True, max_length=128
)

train_dataset = TensorDataset(
    torch.tensor(train_encodings["input_ids"]),
    torch.tensor(train_encodings["attention_mask"]),
    torch.tensor(y_train.values)
)

test_dataset = TensorDataset(
    torch.tensor(test_encodings["input_ids"]),
    torch.tensor(test_encodings["attention_mask"]),
    torch.tensor(y_test.values)
)


# In[ ]:


train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=8)


# In[ ]:


optimizer = torch.optim.AdamW(bert_model.parameters(), lr=2e-5)

bert_model.train()
for epoch in range(1):
    loop = tqdm(train_loader)
    for batch in loop:
        input_ids, attention_mask, labels = [x.to(device) for x in batch]
        optimizer.zero_grad()
        outputs = bert_model(
            input_ids, attention_mask=attention_mask, labels=labels
        )
        loss = outputs.loss
        loss.backward()
        optimizer.step()
        loop.set_description(f"Epoch {epoch}")
        loop.set_postfix(loss=loss.item())


# In[ ]:


bert_model.eval()
preds, true_labels = [], []

with torch.no_grad():
    for batch in test_loader:
        input_ids, attention_mask, labels = [x.to(device) for x in batch]
        outputs = bert_model(input_ids, attention_mask=attention_mask)
        logits = outputs.logits
        preds.extend(torch.argmax(logits, dim=1).cpu().numpy())
        true_labels.extend(labels.cpu().numpy())

print("Accuracy :", accuracy_score(true_labels, preds))
print("Precision:", precision_score(true_labels, preds))
print("Recall   :", recall_score(true_labels, preds))
print("F1 Score :", f1_score(true_labels, preds))


# In[ ]:


get_ipython().system('pip install -q matplotlib seaborn')


# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[ ]:


cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Fake", "Real"],
            yticklabels=["Fake", "Real"])
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix - TF-IDF Model")
plt.show()


# In[ ]:


accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

metrics = ["Accuracy", "F1 Score"]
values = [accuracy, f1]

plt.figure(figsize=(5,4))
plt.bar(metrics, values)
plt.ylim(0,1)
plt.title("TF-IDF Model Performance")
plt.ylabel("Score")
plt.show()


# In[ ]:


cm_bert = confusion_matrix(true_labels, preds)

plt.figure(figsize=(5,4))
sns.heatmap(cm_bert, annot=True, fmt="d", cmap="Greens",
            xticklabels=["Fake", "Real"],
            yticklabels=["Fake", "Real"])
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix - BERT Model")
plt.show()


# In[ ]:


accuracy_bert = accuracy_score(true_labels, preds)
f1_bert = f1_score(true_labels, preds)

metrics = ["Accuracy", "F1 Score"]
values = [accuracy_bert, f1_bert]

plt.figure(figsize=(5,4))
plt.bar(metrics, values)
plt.ylim(0,1)
plt.title("BERT Model Performance")
plt.ylabel("Score")
plt.show()


# In[ ]:


bert_model.save_pretrained("bert_fake_news_model")
tokenizer.save_pretrained("bert_fake_news_model")


# In[ ]:


get_ipython().system('zip -r bert_fake_news_model.zip bert_fake_news_model')

files.download("tfidf_vectorizer.pkl")
files.download("fake_news_classifier.pkl")
files.download("bert_fake_news_model.zip")


# In[ ]:


get_ipython().system('rm app.py')


# In[ ]:


ls


# In[ ]:


get_ipython().system('pip install -q streamlit transformers torch')


# In[ ]:


from google.colab import files
files.upload()

get_ipython().system('unzip bert_fake_news_model.zip')


# In[ ]:


get_ipython().run_cell_magic('writefile', 'app.py', 'import streamlit as st\nimport torch\nfrom transformers import BertTokenizer, BertForSequenceClassification\n\nst.set_page_config(page_title="Fake News Detection using BERT")\n\n@st.cache_resource\ndef load_model():\n    tokenizer = BertTokenizer.from_pretrained("bert_fake_news_model")\n    model = BertForSequenceClassification.from_pretrained("bert_fake_news_model")\n    model.eval()\n    return tokenizer, model\n\ntokenizer, model = load_model()\n\nst.title("📰 Fake News Detection using BERT")\n\nnews_text = st.text_area("Enter News Article Text")\n\nif st.button("Predict"):\n    if news_text.strip() == "":\n        st.warning("Please enter some news text")\n    else:\n        inputs = tokenizer(\n            news_text,\n            return_tensors="pt",\n            truncation=True,\n            padding=True,\n            max_length=512\n        )\n\n        with torch.no_grad():\n            outputs = model(**inputs)\n            prediction = torch.argmax(outputs.logits, dim=1).item()\n\n        if prediction == 1:\n            st.success("✅ Real News")\n        else:\n            st.error("❌ Fake News")\n')


# In[ ]:


get_ipython().system('streamlit run app.py &>/content/logs.txt &')


# In[ ]:


get_ipython().system('wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64')
get_ipython().system('chmod +x cloudflared-linux-amd64')


# In[ ]:


get_ipython().system('./cloudflared-linux-amd64 tunnel --url http://localhost:8501')

