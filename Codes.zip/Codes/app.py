import streamlit as st
import torch
from transformers import BertTokenizer, BertForSequenceClassification

st.set_page_config(page_title="Fake News Detection using BERT")

@st.cache_resource
def load_model():
    tokenizer = BertTokenizer.from_pretrained("bert_fake_news_model")
    model = BertForSequenceClassification.from_pretrained("bert_fake_news_model")
    model.eval()
    return tokenizer, model

tokenizer, model = load_model()

st.title("📰 Fake News Detection using BERT")

news_text = st.text_area("Enter News Article Text")

if st.button("Predict"):
    if news_text.strip() == "":
        st.warning("Please enter some news text")
    else:
        inputs = tokenizer(
            news_text,
            return_tensors="pt",
            truncation=True,
            padding=True,
            max_length=512
        )

        with torch.no_grad():
            outputs = model(**inputs)
            prediction = torch.argmax(outputs.logits, dim=1).item()

        if prediction == 1:
            st.success("✅ Real News")
        else:
            st.error("❌ Fake News")